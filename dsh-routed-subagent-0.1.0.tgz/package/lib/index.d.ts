/**
 * dsh-routed-subagent — complexity-routed subagent delegation.
 *
 * Registers a model-facing delegation tool whose input includes a runtime
 * `tier`; each configured tier names the provider, model, token cap, and
 * optional reasoning effort the spawned child runs under, plus the spawn chain
 * that child itself may delegate through. The calling model judges task
 * complexity per delegation and picks accordingly.
 *
 * Built entirely on public seams: `ctx.subagents.start()` already carries
 * per-start {@link AgentOptions}, and the agent-scoped `agent/request`
 * waterfall allows replacing the call config — so reasoning effort follows the
 * tier without any upstream change.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "routed-subagent";
export declare const inject: string[];
/** Plugin configuration (cordis.yml row config; flags never reach here). */
export interface Config {
    /** Registered tool name; must not collide with another mounted tool. Default `routed_subagent`. */
    toolName?: string;
    /** Subagent provider name on `ctx.subagents`. Default `spawn` (the in-process spawn backend). */
    providerName?: string;
    /** Expose `run_in_background` (default true); disabled instances omit the parameter. */
    enableRunInBackground?: boolean;
    /**
     * Absolute delegation-depth cap for children started by this tool, or
     * `'provider-managed'` to leave recursion budget to the provider. Per-tier
     * spawn chains bound what deeper delegation may exist at all.
     */
    maxDepth?: number | 'provider-managed';
    /** Tier names top-level agents may use. Defaults to every configured tier. */
    rootTiers?: string[];
    /** Required tier table — see README. A missing or invalid table fails the load loudly. */
    tiers: unknown;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
