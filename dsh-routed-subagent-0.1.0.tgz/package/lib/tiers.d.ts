/**
 * Pure tier-table logic for the routed subagent tool: validation at load,
 * caller-scoped availability, and the spawn-chain policy. No harness imports —
 * everything here is unit-testable without a Cordis context.
 * @module dsh-routed-subagent/tiers
 */
/** One configured runtime tier: where a delegated child runs and what it may spawn. */
export interface TierDefinition {
    /** LLM provider route the child's requests use (must resolve to a registered adapter at call time). */
    provider: string;
    /** Model id interpreted by the selected provider adapter. */
    model: string;
    /** Optional per-request output-token cap for the child. */
    maxTokens?: number;
    /**
     * Optional reasoning effort applied to every child request through the
     * `agent/request` waterfall, overriding whatever the child inherited.
     */
    reasoningEffort?: string;
    /** Optional per-child persona shadowing the deployment persona. Requires the provider's persona capability. */
    persona?: string;
    /**
     * One-line guidance shown to the calling model next to this tier's name in
     * the tool description — the actual routing signal.
     */
    guidance?: string;
    /**
     * Tier names children of THIS tier may delegate to. Defaults to no further
     * delegation; unknown names fail the load.
     */
    spawnable?: readonly string[];
}
/** The validated tier table keyed by tier name. */
export type TierTable = Readonly<Record<string, TierDefinition>>;
/**
 * Validate raw configuration into a {@link TierTable}, failing loud with an
 * actionable message naming the first problem found.
 * @param input - the raw `tiers` mapping as read from cordis.yml.
 * @returns the validated table (same shape, narrowed types).
 * @throws when the table is absent, empty, or any entry or reference is invalid.
 */
export declare function parseTierTable(input: unknown): TierTable;
/**
 * Resolve the root delegation menu: the configured allowlist, defaulting to
 * every configured tier.
 * @param tiers - the validated tier table.
 * @param configured - explicit `rootTiers` from config, when present.
 * @returns the ordered tier names top-level agents may delegate to.
 * @throws when a configured root tier names no entry in the table.
 */
export declare function rootTierNames(tiers: TierTable, configured: readonly string[] | undefined): readonly string[];
/**
 * Resolve which tiers ONE calling context may delegate to. Top-level agents
 * get the root menu; a spawned child gets its tier's spawn chain; an unknown
 * context (stale tracking after recomposition) gets nothing.
 * @param tiers - the validated tier table.
 * @param roots - the resolved root menu.
 * @param callerTier - the caller's tracked tier, or undefined at top level.
 * @returns the allowed tier names, in table order for stable prompts.
 */
export declare function allowedTiersFor(tiers: TierTable, roots: readonly string[], callerTier: string | undefined): readonly string[];
